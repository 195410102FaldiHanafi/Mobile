package id.riski.rifaldi.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }



        private fun tambah() {
        val dua         = findViewById<EditText>(R.id.dua)
        val tiga        = findViewById<EditText>(R.id.tiga)
        val hasil      = findViewById<TextView>(R.id.hasil)

        val jumlah      = dua.text.toString().toDouble() + tiga.text.toString().toDouble()
        hasil.text     = jumlah.toString()


}
}